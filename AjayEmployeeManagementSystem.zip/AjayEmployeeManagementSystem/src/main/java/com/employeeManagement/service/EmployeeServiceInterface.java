package com.employeeManagement.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.multipart.MultipartFile;

import com.employeeManagement.entity.Employee;

public interface EmployeeServiceInterface {

	Employee addEmployee(Employee employee);

	List<Employee> getAllEmployees();

	Employee getEmployeeById(Long empId);

	Employee deleteEmployeeById(Long empId);

	Employee updateEmployee(Long empId, Employee employee);

	List<Employee> getEmployeeByFirstName(String firstName);

	List<Employee> getEmployeeByLastName(String lastName);

	Employee getEmployeeByPhone(Long phone);

	Employee getEmployeeByEmail(String email);
	
	//public Employee uploadImage( MultipartFile imageFile,@PathVariable("empId") Long empId);

	Employee uploadImage(Long empId,Employee emp);
}
