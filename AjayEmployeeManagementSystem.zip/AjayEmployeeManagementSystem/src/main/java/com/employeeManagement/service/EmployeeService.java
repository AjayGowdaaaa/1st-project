package com.employeeManagement.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagement.custom.exception.BusinessException;
import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;

@Service
public class EmployeeService  implements EmployeeServiceInterface {


	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee (Employee employee) {

		if(employee.getFirstName().isEmpty() || employee.getFirstName().length()==0) {
			throw new BusinessException("601","Please Enter valid First Name");
		}
		try {
			Employee savedEmployee = employeeRepository.save(employee);
			return savedEmployee;
		}catch (IllegalArgumentException e) {
			throw new BusinessException("602","First Name should be Greater than 3 character"+ e.getMessage());
		}catch (Exception e) {
			throw new BusinessException("603","Something went wrong in service layer while adding employee"+ e.getMessage());
		}
	}


	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> empoyeeList= null;
		try {
			empoyeeList = employeeRepository.findAll();
		} catch (Exception e) {
			throw new BusinessException("605","Something went wrong in service layer while fetching all employee details "+ e.getMessage());
		}
		if (empoyeeList.isEmpty()) {
			throw new BusinessException("604","List is Empty");
		}
		return empoyeeList;

	}

	@Override
	public Employee getEmployeeById(Long empId) {
		
		try {
			return employeeRepository.findById(empId).get();
		} catch (IllegalArgumentException e) {
			throw new BusinessException("606","Employee ID is null, Please enter valid ID"+ e.getMessage());
		}catch (NoSuchElementException e) {
			throw new BusinessException("607","Employee ID not found in DataBase "+ e.getMessage());
		}

	}
	

	@Override
	public Employee updateEmployee(long empId ,Employee employee) {
		if (employeeRepository.findById(empId).get().equals(null)) {
			throw new BusinessException("608","Employee Id not found , Please Enter Valid ID");
		}
		try {
		Employee updatedEmployee=	employeeRepository.save(employee);
		return updatedEmployee;
		} catch (IllegalArgumentException e) {
			throw new BusinessException("609","Employee ID is null, Please enter valid ID"+ e.getMessage());
		}catch (NoSuchElementException e) {
			throw new BusinessException("610","Employee ID not found in DataBase "+ e.getMessage());
		}
		
}

	@Override
	public void deleteEmployeeById(Long empId) {
		if (employeeRepository.findById(empId).get().equals(null)) {
			throw new BusinessException("611","Employee Id not found , Please Enter Valid ID");
		}
		try {
			employeeRepository.deleteById(empId);
		} catch (IllegalArgumentException e) {
			throw new BusinessException("612","Employee ID is null, Please enter valid ID"+ e.getMessage());
		}catch (NoSuchElementException e) {
			throw new BusinessException("613","Employee ID not found in DataBase"+ e.getMessage());
		}

	}


	


}
