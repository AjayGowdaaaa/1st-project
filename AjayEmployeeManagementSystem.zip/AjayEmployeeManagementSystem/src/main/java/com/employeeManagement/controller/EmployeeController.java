package com.employeeManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.employeeManagement.custom.exception.BusinessException;
import com.employeeManagement.custom.exception.ControllerException;
import com.employeeManagement.entity.Employee;
import com.employeeManagement.service.EmployeeServiceInterface;

@RestController
@RequestMapping("/")
public class EmployeeController {

	@Autowired
	private EmployeeServiceInterface employeeServiceInterface;

	/*
	 * Register page there we can add employee details and storing in Employee repository
	 * It is mapped to add employee method in employee service interface
	 */
	@PostMapping("/register")
	public ResponseEntity<?> addEmployee(@RequestBody Employee employee){
		try {
			Employee savedEmployee = employeeServiceInterface.addEmployee(employee);
			return new ResponseEntity<Employee>(savedEmployee, HttpStatus.CREATED);
		} catch (BusinessException e) {
			ControllerException ce = new ControllerException(e.getErrorCode(),e.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("614","Something went wrong on Controller");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}

	/*
	 * Fetching ALl employees details present in DataBase
	 * It is mapped to getAllEmployees method in employee service interface
	 * It will fetch a All Employees detail present in Data Base
	 */
	@GetMapping("/allEmployees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		List<Employee> listOfEmployees = employeeServiceInterface.getAllEmployees();
		return new ResponseEntity<List<Employee>>(listOfEmployees, HttpStatus.OK) ;
	}

	/*
	 * Fetching one employee details by Using Id 
	 * It is mapped to getEmployeeById method in employee service interface
	 * It will fetch a Particular Employee details by ID
	 */

	@GetMapping("/employeeById/{empId}")
	public ResponseEntity<?> getEmployeeById(@PathVariable("empId") Long empId){		
		try {
			Employee employeeObtained = employeeServiceInterface.getEmployeeById(empId);
			return new ResponseEntity<Employee>(employeeObtained, HttpStatus.OK) ;
		} catch (BusinessException e) {
			ControllerException ce = new ControllerException(e.getErrorCode(),e.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("615","Something went wrong on Controller");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}

	}

	/*
	 * Fetching one employee details by Using Id 
	 * if id is present it will update else it will throw exception
	 * It is mapped to update method in employee service interface
	 * It will fetch a Particular Employee details by ID and UPDATE the employee details
	 */

	@PutMapping("/update/{empId}")
	public ResponseEntity<?> updateEmployee(@PathVariable long empId,@RequestBody Employee employee){
		try {
			Employee savedEmployee = employeeServiceInterface.updateEmployee( empId ,employee);
			return new ResponseEntity<Employee>(savedEmployee, HttpStatus.CREATED);

		} catch (BusinessException e) {
			ControllerException ce = new ControllerException(e.getErrorCode(),e.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("616","Employee Id Not Found in Data Base, Please Ente Valid Employee ID");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}

	/*
	 * Fetching one employee details by Using Id and Deleting that particular Employee Object
	 * It is mapped to deleteEmployeeById method in employee service interface
	 * It will Delete that Employee Object from Data Base
	 */


	@DeleteMapping("/delete/{empId}")
	public ResponseEntity<?> deleteEmployeeById(@PathVariable("empId") Long empId){
		try {
			employeeServiceInterface.deleteEmployeeById(empId);
			return new ResponseEntity<Void>( HttpStatus.ACCEPTED) ;
		} catch (BusinessException e) {
			ControllerException ce = new ControllerException(e.getErrorCode(),e.getErrorMessage());
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			ControllerException ce = new ControllerException("617","Employee Id Not Found On Data Baser");
			return new ResponseEntity<ControllerException>(ce, HttpStatus.BAD_REQUEST);
		}
	}


}

