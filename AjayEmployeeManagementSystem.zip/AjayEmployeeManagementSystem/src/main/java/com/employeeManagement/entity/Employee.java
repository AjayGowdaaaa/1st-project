package com.employeeManagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import lombok.Data;

/*
 * Creating a Employee class with respective attributes
 * Using Lombak so that it will generate Getter and Setter for all the attributes
 * Note - empid is a primary key
 */

@Data
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long empId;
	private String ESTUATE_ID;
	@NotNull
	private String firstName;
	private String lastName;
	private String dateOfBirth;
	@Email 
	private String email;
	private Long phone;
	private String photoPath;
	@Lob
	private byte[] photo;
	
}
