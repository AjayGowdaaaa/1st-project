package com.ebs.model;

import lombok.Data;

@Data
public class UserModel {
	private String userName;
	private String email;
	private String password;
	private String matchingPassword;
	private String role; 
}
