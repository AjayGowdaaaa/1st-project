package com.ebs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ebs.entity.User;
import com.ebs.model.UserModel;
import com.ebs.service.UserService;


@RestController
@RequestMapping("/ebs")
public class EBS_Controller {

	@Autowired
	private UserService service;

//	//Testing 
//	@GetMapping("/")
//	public String ebs() {
//		return "Welcome to EBS";
//	}
//	@GetMapping("/home")
//	public String home() {
//		return "Welcome Home";
//	}
//	@GetMapping("/admin")
//	public String admin() {
//		return "This is Admin";
//	}

	@PostMapping("/register")
	public ResponseEntity<?> register( @RequestBody UserModel userModel) {
		User user = service.register(userModel);
		return new ResponseEntity<User>(user, HttpStatus.CREATED);
	}


}
