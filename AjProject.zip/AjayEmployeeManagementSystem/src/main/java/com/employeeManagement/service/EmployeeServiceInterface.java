package com.employeeManagement.service;

import java.util.List;

import com.employeeManagement.entity.Employee;

public interface EmployeeServiceInterface {

	Employee addEmployee(Employee employee);

	List<Employee> getAllEmployees();
	
	Employee getEmployeeById(Long empId);

	void deleteEmployeeById(Long empId);

}
