package com.employeeManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeeManagement.custom.exception.BusinessException;
import com.employeeManagement.entity.Employee;
import com.employeeManagement.repository.EmployeeRepository;

@Service
public class EmployeeService  implements EmployeeServiceInterface {


	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee addEmployee (Employee employee) {
		try { 
			if(employee.getFirstName().isEmpty() || employee.getFirstName().length()==0) {
				throw new BusinessException("601","Please Enter valid First Name");
			}

			Employee savedEmployee = employeeRepository.save(employee);
			return savedEmployee;
		}catch (IllegalArgumentException e) {
			throw new BusinessException("602","First Name should be Greater than 3 character"+ e.getMessage());
		}catch (Exception e) {
			throw new BusinessException("602","Something went wrong in service layer"+ e.getMessage());
		}
	}

	@Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	@Override
	public Employee getEmployeeById(Long empId) {
		return employeeRepository.findById(empId).get();
	}

	@Override
	public void deleteEmployeeById(Long empId) {
		employeeRepository.deleteById(empId);
		System.out.println("Deleted");
	}

	

}
