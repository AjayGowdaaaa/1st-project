package com.employeeManagement.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

/*
 * Creating a Employee class with respective attributes
 * Using Lombak so that it will generate Getter and Setter for all the attributes
 * Note - empid is a primary key
 */
@Data
@Entity
public class Employee {
	@Id @GeneratedValue(strategy = GenerationType.AUTO)
	private Long empId;
	private String firstName;
	private String lastName;
	@Column(name="DOB")
	private Date dateOfBirth;
	private String email;
	private Long phone;
	private String photoPath;
}
